Robbie Perry - A00996041 - robbieperry22@gmail.com
David Perez - A00994971 - snow.nh@gmail.com

We have completed everything to the best of our knowledge.

Some minor challenges were encountered along the way. One problem was that the 12 signs weren't staying
together in a grid pattern. It turned out that the images were slightly different sizes, which was making
them stick out. Resizing the images fixed the problem. 